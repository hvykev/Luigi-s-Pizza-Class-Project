<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Luigi's Pizza</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="site.css">
        
    </head>
    <body>
        <!--Empty header placeholder-->
      
        <header>
          
        </header>
        
        <nav>
            <ul>
                <h1>Luigi's Pizza</h1>   
                <li><a href="index.html">Home</a></li>
                <li><a href="pizza.html">Pizza</a></li>
                <li><a href="pasta.html">Pasta</a></li>
                <li><a href="sides.html">Sides</a></li>
                <li><a href="deals.html">Deals</a></li>
                <li><a href="locations.html">Locations</a></li>
                <li><a href="cart.html">Cart</a></li>
            </ul>    
        </nav>    
        
        <table>
        <tr>
            <td>
                <div>
           <ul>
               <h2>Oven Fresh Deals!!!</h2>
                <li><a href="deals.html">Deal 1</a></li>
                <li><a href="deals.html">Deal 2</a></li>
                <li><a href="deals.html">Deal 3</a></li>
                <li><a href="deals.html">Deal 4</a></li>
            </ul>   
                </div>
        </td>
        
            <td>
            <img src="pizza2.png"alt="Pizza" width="800" height="300">  
            </td>
        </tr>
        </table>
        
        <footer>
            <small><i>Copyright &copy; 2016 Luigi's Pizza</i></small>
        </footer>
    
    </body>
</html>


<?php
//Home
$servername = "localhost";
$username = "username";
$password = "password";

//Retrieve from the database pointed to by the $dbRecords resource the first name from the table.
/*$dbLocalhost = mysql_connect("localhost", "root", "")
        or die("Could not connect: " . mysql_error());

mysql_select_db("Deals", $dbLocalhost)
        or die("Could not find database: " . mysql_error());
*/
//new function to include the database2.php file
require_once("database3");

//query the database deals
$dbRecords = mysql_query("SELECT * FROM deals", $dbLocalhost)
        or die("Problem reading table: " . mysql_error());

//displays records one at a time
/*
$strID = mysql_result(dbRecords, 0, "Id");
$strName = mysql_result($dbRecords, 0, "Name");
$strDescription = mysql_result($dbRecords, 0, "Description");
$intQuantity = mysql($dbRecords, 0, "Quantity");
$floCost = mysql($dbRecords, 0, "Name");
        
echo "<p>$intId $strName $strDescription $intQuantity $floCost</p>";
*/

//this while loop returns an arry that has the database record
while ($arrRecord = mysql_fetch_row($dbRecords))
{
    echo "<p>". $arrRecord[0] . " ";
    echo $arrRecord[1] . " ";
    echo $arrRecord[2] . " ";
    echo $arrRecord[3] . " ";
    echo $arrRecord[4] . "</p>";
}
?>

