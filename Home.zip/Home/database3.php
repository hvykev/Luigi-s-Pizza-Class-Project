<?php
//database3.php

$strLocation = "Home";//if accessing from "Work", simply comment out "Home".
//$strLocation = "Work";

if ($strLocation == "Home")
{
    $dbLocalhost = mysql_connect("localhost", "root", "")
            or die("Could not connect: " . mysql_error());
    
    mysql_select_db("Deals", $dbLocalhost)
            or die("Could not find database: " . mysql_error());
}
else
{
    $dbLocalhost = mysql_connect("localhost", "usename", "password")
            or die("Could not connect: " . mysql_error());
    
    mysql_db("anotherdatabase", $dbLocalhost)
            or die("Could not find database: " . mysql_error());
}
?>


