<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Luigi's Pizza</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="site.css">
    </head>
    <body>
        <!--Empty header placeholder-->
      
        <header>
          
        </header>
        
        <nav>
            <ul>
                <h1>Luigi's Pizza</h1>   
                <li><a href="index.html">Home</a></li>
                <li><a href="pizza.html">Pizza</a></li>
                <li><a href="pasta.html">Pasta</a></li>
                <li><a href="sides.html">Sides</a></li>
                <li><a href="deals.html">Deals</a></li>
                <li><a href="locations.html">Locations</a></li>
                <li><a href="cart.html">Cart</a></li>
            </ul>    
        </nav>    
        
        <table>
        <tr>
            <td>
                <div>
           <ul>
               <h2>Oven Fresh Deals!!!</h2>
                <li><a href="deals.html">Deal 1</a></li>
                <li><a href="deals.html">Deal 2</a></li>
                <li><a href="deals.html">Deal 3</a></li>
                <li><a href="deals.html">Deal 4</a></li>
            </ul>   
                </div>
        </td>
        
            <td>
            <img src="pizza1.jpg"alt="Pizza" width="400" height="400"> 
            <img src="pizza3.jpg"alt="Pizza" width="400" height="400">
            <img src="pizza4.jpg"alt="Pizza" width="400" height="400">
            <img src="pizza5.jpg"alt="Pizza" width="400" height="400">
            </td>
        </tr>
        </table>
        
        <footer>
            <small><i>Copyright &copy; 2016 Luigi's Pizza</i></small>
        </footer>
    
    </body>
</html>


<?php





?>

