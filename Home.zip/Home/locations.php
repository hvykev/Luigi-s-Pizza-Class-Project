<?php
session_start();

?>

<!DOCTYPE html>
<html>  
    
<body style="background-color: slategray">
    
<head>
     
<style>
ul#menu {
    padding: 0;
}

ul#menu li {
    display: inline;
}

ul#menu li a {
    background-color: black;
    color: white;
    padding: 10px 20px;
    text-decoration: none;
    border-radius: 4px 4px 0 0;
}

ul#menu li a:hover {
    background-color: red;
}
</style>
    
<header style="background-color:black; color:white; padding:20px;">    
<h2 style="text-align: center;">Welcome to Luigi's Pizza!</h2>

<ul id="menu">
  <li><a href="/html/default.asp">Home</a></li>
  <li><a href="/html/default.asp">Pizza</a></li>
  <li><a href="/html/default.asp">Pasta</a></li>
  <li><a href="/html/default.asp">Sides</a></li>
  <li><a href="/html/default.asp">About Us</a></li>
  <li><a href="/html/default.asp">Contact</a></li>
  <li><a href="/html/default.asp">Locations</a></li>
  <li><a href="/html/default.asp">Cart</a></li>
</ul>  
</header>
</head>

<ul class="side-nav">
  <li><a href="#">Deal 1</a></li>
  <li><a href="#">Deal 2</a></li>
  <li><a href="#">Deal 3</a></li>
  <li><a href="#">Deal 4</a></li>
</ul>   
    
</body>
</html>


<?php





?>

